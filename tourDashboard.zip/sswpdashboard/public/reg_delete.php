<?php
$con=mysqli_connect('localhost','root','','sswpdashboard');
$id=$_GET['id'];
$sql="delete from register where id=$id";
if(mysqli_query($con,$sql))
{
    echo"record deteted";
}
else
{
    echo"not deleted";
}
?>